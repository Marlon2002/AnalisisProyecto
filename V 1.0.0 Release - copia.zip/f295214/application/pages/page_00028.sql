prompt --application/pages/page_00028
begin
--   Manifest
--     PAGE: 00028
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>58477965052683218608
,p_default_application_id=>295214
,p_default_id_offset=>0
,p_default_owner=>'WKSP_UMGESPACIOTRABAJO'
);
wwv_flow_imp_page.create_page(
 p_id=>28
,p_name=>'OLVIDAR'
,p_alias=>'OLVIDAR'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Olvide Mi Contrase\00F1a')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'JNUNEZL@MIUMG.EDU.GT'
,p_last_upd_yyyymmddhh24miss=>'20231019021629'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1447390371902323813)
,p_button_sequence=>40
,p_button_name=>'Cambiar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(74818381056717626720)
,p_button_image_alt=>unistr('CAMBIAR CONTRASE\00D1A')
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1447390847114323818)
,p_branch_name=>'Volver2'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1447389938031323809)
,p_name=>'P28_NUEVA'
,p_item_sequence=>20
,p_prompt=>unistr('Contrase\00F1a Nueva')
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(74818378513629626719)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1447390002565323810)
,p_name=>'P28_CONFIRMAR'
,p_item_sequence=>30
,p_prompt=>unistr('Confirmar Contrase\00F1a')
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(74818378513629626719)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1447390145582323811)
,p_name=>'P28_DPI'
,p_item_sequence=>10
,p_prompt=>'Ingrese su DPI'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(74818378513629626719)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1447390434153323814)
,p_validation_name=>'New'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'l_dpi varchar(100);',
'BEGIN',
'SELECT DPI INTO l_dpi FROM AUT_USERS',
'WHERE UPPER(DPI) = UPPER(:P28_DPI);',
'IF :P28_DPI = l_dpi THEN',
'RETURN TRUE;',
'ELSE',
'RETURN FALSE;',
'END IF;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'DPI INVALIDO'
,p_associated_item=>wwv_flow_imp.id(1447390145582323811)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1447390520490323815)
,p_validation_name=>'New_1'
,p_validation_sequence=>20
,p_validation=>':P28_NUEVA = :P28_CONFIRMAR'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('LAS CONTRASE\00D1AS NO COINCIDEN')
,p_associated_item=>wwv_flow_imp.id(1447389938031323809)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1447391476648323824)
,p_validation_name=>'New_2'
,p_validation_sequence=>30
,p_validation=>'P28_DPI'
,p_validation2=>'^\d{13}$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'INGRESE UN DPI VALIDO'
,p_associated_item=>wwv_flow_imp.id(1447390145582323811)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1447390681591323816)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CAMBIO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE AUT_USERS',
'SET PASSWORD = :P28_CONFIRMAR',
'WHERE DPI = :P28_DPI;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1447390371902323813)
,p_internal_uid=>1447390681591323816
);
wwv_flow_imp.component_end;
end;
/
