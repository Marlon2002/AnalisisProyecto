prompt --application/pages/page_00027
begin
--   Manifest
--     PAGE: 00027
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>58477965052683218608
,p_default_application_id=>295214
,p_default_id_offset=>0
,p_default_owner=>'WKSP_UMGESPACIOTRABAJO'
);
wwv_flow_imp_page.create_page(
 p_id=>27
,p_name=>'FORM_CONTRA'
,p_alias=>'FORM-CONTRA'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Cambiar Contrase\00F1a')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'JNUNEZL@MIUMG.EDU.GT'
,p_last_upd_yyyymmddhh24miss=>'20231019055003'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1447389245261323802)
,p_button_sequence=>40
,p_button_name=>'CAMBIAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--warning'
,p_button_template_id=>wwv_flow_imp.id(74818381056717626720)
,p_button_image_alt=>'CAMBIAR'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1447390705707323817)
,p_branch_name=>'Volver'
,p_branch_action=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1284406942479062649)
,p_name=>'P27_CONTRA'
,p_item_sequence=>10
,p_prompt=>unistr('Contrase\00F1a')
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(74818378513629626719)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1284407099869062650)
,p_name=>'P27_NUEVA'
,p_item_sequence=>20
,p_prompt=>unistr('Nueva contrase\00F1a')
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(74818378513629626719)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1447389129252323801)
,p_name=>'P27_CONFIRMAR'
,p_item_sequence=>30
,p_prompt=>'Confirmar'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(74818378513629626719)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1447389378342323803)
,p_validation_name=>'ANTIGUA'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'l_current_pass varchar(100);',
'BEGIN',
'SELECT PASSWORD INTO l_current_pass FROM AUT_USERS',
'WHERE UPPER(EMAIL) = UPPER(:APP_USER);',
'IF l_current_pass = :P27_CONTRA THEN',
'RETURN TRUE;',
'ELSE',
'RETURN FALSE;',
'END IF;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('CONTRASE\00D1A INCORRECTA')
,p_associated_item=>wwv_flow_imp.id(1284406942479062649)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1447389488035323804)
,p_validation_name=>'New'
,p_validation_sequence=>20
,p_validation=>':P27_NUEVA = :P27_CONFIRMAR'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('LAS CONTRASE\00D1AS NO COINCIDEN')
,p_associated_item=>wwv_flow_imp.id(1284407099869062650)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1447389598236323805)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PROCESSES'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE AUT_USERS',
'SET PASSWORD = :P27_CONFIRMAR',
'WHERE UPPER(EMAIL) = UPPER(:APP_USER);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>1447389598236323805
);
wwv_flow_imp.component_end;
end;
/
