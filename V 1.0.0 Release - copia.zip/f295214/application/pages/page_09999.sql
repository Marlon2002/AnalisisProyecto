prompt --application/pages/page_09999
begin
--   Manifest
--     PAGE: 09999
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>58477965052683218608
,p_default_application_id=>295214
,p_default_id_offset=>0
,p_default_owner=>'WKSP_UMGESPACIOTRABAJO'
);
wwv_flow_imp_page.create_page(
 p_id=>9999
,p_name=>'Login Page'
,p_alias=>'LOGIN'
,p_step_title=>'GESTION_DOCUMENTOS - Log In'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Login-container {',
'    background-image: url(''#APP_FILES#back.jpg'');',
'    background-repeat: no-repeat;',
'    background-size: cover;',
'}',
'',
'.t-Login-logo {',
'    background-image: url("#APP_FILES#icons/app-icon-144-rounded.png");',
'    background-size: cover;',
'    border-radius: 50%;',
'    width: 80px;',
'    height: 80px;',
'}',
'',
'.t-Login-region .t-Login-body .t-Form-fieldContainer:not(.t-Form-fieldContainer--floatingLabel) .apex-item-text {',
'    font-size: 16px;',
'    padding: 4px 36px;',
'    height: 40px;',
'    border-radius: 20px;',
'}',
'',
'.a-Button--hot,',
'.t-Button--hot:not(.t-Button--simple),',
'body .ui-button.ui-button--hot,',
'body .ui-state-default.ui-priority-primary {',
'    background-color: #002eb7;',
'    color: #f9f9f9;',
'    border-radius: 15px;',
'}',
'',
'.a-Button--hot:hover,',
'.a-Button--hot:not(:active):focus,',
'.t-Button--hot:not(.t-Button--simple):hover,',
'.t-Button--hot:not(.t-Button--simple):not(:active):focus,',
'body .ui-button.ui-button--hot:hover,',
'body .ui-button.ui-button--hot:not(:active):focus,',
'body .ui-state-default.ui-priority-primary:hover,',
'body .ui-state-default.ui-priority-primary:not(:active):focus {',
'    background-color: #363b40;',
'}'))
,p_step_template=>wwv_flow_imp.id(74818215185666626649)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'12'
,p_last_updated_by=>'JNUNEZL@MIUMG.EDU.GT'
,p_last_upd_yyyymmddhh24miss=>'20231019053957'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74818542419980626783)
,p_plug_name=>'Gestor de Documentos'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(74818302635707626685)
,p_plug_display_sequence=>10
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1447389844085323808)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(74818542419980626783)
,p_button_name=>'OLVIDAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(74818381056717626720)
,p_button_image_alt=>unistr('Olvide mi contrase\00F1a')
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74818547624633626785)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(74818542419980626783)
,p_button_name=>'LOGIN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>wwv_flow_imp.id(74818381056717626720)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'ACCEDER'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(73514321199801501917)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(74818542419980626783)
,p_button_name=>'SIGNUP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--success:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(74818381143042626720)
,p_button_image_alt=>'REGISTRARSE'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-user-plus'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1447390939342323819)
,p_name=>'P9999_AREA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(74818542419980626783)
,p_prompt=>'Area'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'AREAS.NOMBRE_AREA'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'AREA'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(74818378218236626719)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73514321569306501921)
,p_name=>'P9999_ROL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(74818542419980626783)
,p_prompt=>'Rol'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_ROL2'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID, ROL VALUE',
'FROM ROLES_PUESTOS',
'WHERE ID_AREA = :P9999_AREA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'ROL'
,p_lov_cascade_parent_items=>'P9999_AREA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(74818378218236626719)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74818544459572626784)
,p_name=>'P9999_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74818542419980626783)
,p_prompt=>'Correo Empresarial'
,p_placeholder=>'Correo Empresarial'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_tag_attributes=>'autocomplete="username"'
,p_field_template=>wwv_flow_imp.id(74818378218236626719)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74818545456283626784)
,p_name=>'P9999_PASSWORD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(74818542419980626783)
,p_prompt=>unistr('Contrase\00F1a')
,p_placeholder=>unistr('Contrase\00F1a')
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_tag_attributes=>'autocomplete="current-password"'
,p_field_template=>wwv_flow_imp.id(74818378218236626719)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74818546992692626785)
,p_name=>'P9999_REMEMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(74818542419980626783)
,p_prompt=>'Recordar Usuario'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when=>'apex_authentication.persistent_cookies_enabled'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(74818378218236626719)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74818551262256626786)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Set Username Cookie'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'SEND_LOGIN_USERNAME_COOKIE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>74818551262256626786
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74818552207670626786)
,p_page_process_id=>wwv_flow_imp.id(74818551262256626786)
,p_page_id=>9999
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'lower( :P9999_USERNAME )'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74818553328456626787)
,p_page_process_id=>wwv_flow_imp.id(74818551262256626786)
,p_page_id=>9999
,p_name=>'p_consent'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'ITEM'
,p_value=>'P9999_REMEMBER'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74818548245682626785)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Login'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'LOGIN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>74818548245682626785
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74818549120906626785)
,p_page_process_id=>wwv_flow_imp.id(74818548245682626785)
,p_page_id=>9999
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'ITEM'
,p_value=>'P9999_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74818550028015626786)
,p_page_process_id=>wwv_flow_imp.id(74818548245682626785)
,p_page_id=>9999
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'ITEM'
,p_value=>'P9999_PASSWORD'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74818550659149626786)
,p_page_process_id=>wwv_flow_imp.id(74818548245682626785)
,p_page_id=>9999
,p_name=>'p_set_persistent_auth'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>3
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74818554701164626787)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Page(s) Cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>74818554701164626787
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74818554080779626787)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9999_USERNAME := apex_authentication.get_login_username_cookie;',
':P9999_REMEMBER := case when :P9999_USERNAME is not null then ''Y'' end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>74818554080779626787
);
wwv_flow_imp.component_end;
end;
/
