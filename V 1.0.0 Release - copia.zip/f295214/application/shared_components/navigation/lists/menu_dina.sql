prompt --application/shared_components/navigation/lists/menu_dina
begin
--   Manifest
--     LIST: MENU_DINA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>58477965052683218608
,p_default_application_id=>295214
,p_default_id_offset=>0
,p_default_owner=>'WKSP_UMGESPACIOTRABAJO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1657265377900085049)
,p_name=>'MENU_DINA'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'null,',
'ENTRY_TEXT, ',
'ENTRY_TARGET, ',
'''YES'' AS is_current,',
'NVL(ENTRY_IMAGE,ENTRY_ATTRIBUTE_01) AS LOGO_IMAGE,',
'SUBSTR(ENTRY_TARGET, INSTR(ENTRY_TARGET, '':'', 1, 1)+1 , INSTR(ENTRY_TARGET, '':'', 1, 2) - INSTR(ENTRY_TARGET, '':'', 1, 1)-1 )  AS PAGE_ID',
'from APEX_APPLICATION_LIST_ENTRIES',
'where APPLICATION_ID = 295214',
'and  ENTRY_TEXT = ''Vista de Documentos''',
'or ENTRY_TEXT = ''Perfil de Usuario'';'))
,p_list_status=>'PUBLIC'
);
wwv_flow_imp.component_end;
end;
/
