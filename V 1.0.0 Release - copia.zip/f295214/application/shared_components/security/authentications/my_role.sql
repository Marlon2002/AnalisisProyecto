prompt --application/shared_components/security/authentications/my_role
begin
--   Manifest
--     AUTHENTICATION: MY_ROLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>58477965052683218608
,p_default_application_id=>295214
,p_default_id_offset=>0
,p_default_owner=>'WKSP_UMGESPACIOTRABAJO'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(75311898896123712865)
,p_name=>'MY_ROLE'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'custom_auth'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'FUNCTION custom_auth(p_username  IN VARCHAR2, p_password IN VARCHAR2)',
'  RETURN BOOLEAN',
'AS',
'my_user NUMBER :=0;',
'BEGIN',
'SELECT 1 INTO my_user FROM AUT_USERS',
'WHERE UPPER(EMAIL) = UPPER(p_username)',
'AND PASSWORD = p_password',
'AND ID_ROL = :P9999_ROL',
'AND SYSDATE-1 <= FECHA_EXP;',
'RETURN TRUE;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
'RETURN FALSE;',
'END custom_auth;'))
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
