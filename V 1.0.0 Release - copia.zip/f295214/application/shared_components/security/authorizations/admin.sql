prompt --application/shared_components/security/authorizations/admin
begin
--   Manifest
--     SECURITY SCHEME: ADMIN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>58477965052683218608
,p_default_application_id=>295214
,p_default_id_offset=>0
,p_default_owner=>'WKSP_UMGESPACIOTRABAJO'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(777530813956813431)
,p_name=>'ADMIN'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>'SELECT ID_ROL FROM AUT_USERS WHERE ID_ROL = 1 AND UPPER(EMAIL) = UPPER(:APP_USER);'
,p_error_message=>'NO HAY PERMISOS DE ADMINISTRADOR'
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
