prompt --application/shared_components/globalization/dyntranslations
begin
--   Manifest
--     DYNAMIC TRANSLATIONS: 295214
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>58477965052683218608
,p_default_application_id=>295214
,p_default_id_offset=>0
,p_default_owner=>'WKSP_UMGESPACIOTRABAJO'
);
null;
wwv_flow_imp.component_end;
end;
/
